package com.itmuch.contentcenter.dao.content;

import com.itmuch.contentcenter.domain.entity.content.MidUserShare;
import tk.mybatis.mapper.common.Mapper;

public interface MidUserShareMapper extends Mapper<MidUserShare> {
}