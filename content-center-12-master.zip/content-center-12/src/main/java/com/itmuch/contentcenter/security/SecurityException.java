package com.itmuch.contentcenter.security;

public class SecurityException extends RuntimeException{
}
